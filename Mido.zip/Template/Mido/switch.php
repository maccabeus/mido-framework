<?php
/*
 * ---------------------------------------------------------------------------------
 * Template Switch / Router Configurations
 * ---------------------------------------------------------------------------------
 */
return array(
    /*
     * This is the top level switch as it appeared in the browser
     * for example, if our application is mido, then a top level switch
     * to an admin page might  be like mido/admin. to define this, we will
     * simply use /admin. We can define this to any depth depending on the depth of the
     * switch. For example we could use admin/active/whatever. It is important to
     * arrange similar route close to each other.
     *
     */
    '/admin' => array(
        'namespace' => '',
        'class' => '',
        /* optional parameters
         */
        'process' => '',
        'params' => array(/*
             * here we define the parameters
             */
        ),
    ),
);
