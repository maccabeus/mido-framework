<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Http\Session;

class Globals
{
    protected $GLOBALS;  // variable globals

    public function __construct()
    {
        $this->startSession();
        if (isset($_SESSION['MIDO_GLOBALS'])) {
            $this->GLOBALS = $_SESSION['MIDO_GLOBALS'];
        }
    }

    /*
     * Add a new entry in the global collections
     * @param   string $key`
     * @param   mixed $value
     * @return  bool
     */
    public function add($key, $value)
    {
        if (!$key || !$value) {
            return false;
        }
        /*
         * add the new key in the collection, overwrite if existing key already exist
         */
        if ($this->setSessionElement($key, $value)) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * Get a key value in the global collections
     * @param   string $key`
     * @return  mixed
     */
    public function get($key)
    {
        if (!$key) {
            return false;
        }
        /*
         * return the key value
         */
        return $this->getSessionElement($key);
    }

    /*
     * Start a new session if not existing
     * @return  bool
     */
    private function startSession()
    {
        if (!isset($_SESSION)) {
            session_start();
            return true;
        } else {
            return false;
        }
    }

    /*
     * Get a session variable
     * @return  string
     */
    private function getSessionElement($sessionKey)
    {
        $this->startSession();
        if (isset($this->GLOBALS[$sessionKey])) {
            return $this->GLOBALS[$sessionKey];
        } else {
            return null;
        }
    }

    /*
     * Set a session variable
     * @return  bool
     */
    private function setSessionElement($sessionKey, $newValue = null)
    {
        $this->startSession();
        $this->GLOBALS[$sessionKey] = $newValue;
        $_SESSION['MIDO_GLOBALS'] = $this->GLOBALS;
        return true;
    }
}