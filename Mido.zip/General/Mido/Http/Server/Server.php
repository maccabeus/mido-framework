<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Http\Server;

class Server
{
    protected $server;

    /*
    * check the integrity of the server request
     * against any known form of attack
    * @return  bool
    */
    public function __construct()
    {
        if (!isset($_SERVER)) {
            return false;
        }
        /*
         * perform server integrity check here
         */
        if ($this->serverCheck($_SERVER) == false) {
            return false;
        }
        $this->server = $_SERVER;
        return true;
    }

    /*
    * set some basic server parameters
    * @return  bool/array/null
    */
    public function setServerVariables()
    {
        if (!$this->server) {
            return false;
        }
        //var_dump($this->server);
        $serverArr = array(
            'process_uri' => ($this->server['REQUEST_URI']),
            'process_query' => ($this->server['QUERY_STRING']),
            'process_root' => ($this->server['DOCUMENT_ROOT']),
            'process_full_url' => ($this->server['DOCUMENT_ROOT'] . $this->server['REQUEST_URI']),
            'process_mido_root' => $this->getMidoRoot(),
        );
        return $serverArr;
    }

    /*
     * ---------------------------------------------------------------------------
     * Private function starts here
     * ---------------------------------------------------------------------------
     */

    /*
    * return the full mido document root
     * @param   string  $curUri
    * @return  string/null
    */

    private function getMidoRoot()
    {
        $curUri = $this->server['REQUEST_URI'];
        $curRoot = $this->server['DOCUMENT_ROOT'];

        if (!$curUri || $curUri == null) {
            return null;
        }
        /*
         * split the url and pick the mido base from the array
         */
        $root = explode('/', $curUri);
        if ($root[1]) {
            $midoRoot = ($curRoot . '/' . $root[1]);
            return $midoRoot;
        }
        return null;
    }

    /*
    * check server for security breach
     * @param   array  $server
    * @return  string/null
    */

    private function serverCheck($server)
    {
        /*
         * perform integrity checks
         */

        return true;
    }

    /*
    * check server for security breach
     * @param   string  $includeFile
    * @return  string/null
    */

    private function serverInclude($includeFile)
    {
        /*
         * perform integrity checks
         */
        $base = $this->setServerVariables();
        $basePath = $base['process_mido_root'];
        $fileFullPath = $basePath . "/" . $includeFile;
        include_once $fileFullPath;
        return $fileFullPath;
    }

}