<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Loader;

use Mido\Design\Loader\LoaderAbstract;

class TemplateLoader extends LoaderAbstract
{
    public function loadDefaultTemplate($config = null)
    {
        /*
         * Loads application default template
         * @param   string  $config
         * @return bool
         */

        if ($config == null) {
            /*
             * load configuration file
             */
            $config = $this->loadConfigFile();
        }

        if ($config != null && is_array($config)) {
            /*
             * get the template details and pass it on
             */
            $templateDetails = $config['template'];
            $templateDetails['server']=$this->loadServerVariables();
            return $templateDetails;
        }
    }
}