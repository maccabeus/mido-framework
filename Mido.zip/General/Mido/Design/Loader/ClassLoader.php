<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Loader;

require_once 'LoaderAbstract.php';

class ClassLoader extends LoaderAbstract
{
    public function loadAllClass($midoPath)
    {
        /*
         * Loads all the classes in our application
         * @param   string $midoPath
         * @return  bool
         */
        if (!$midoPath || $midoPath == null) {
            return false;
        }
        /*
         * save the base midoPath on the first run We will use this to track the
         * base directory when auto-loading classes in the ClassLoader.php class
         */
        static $k = 1;
        if ($k == 1) {
            $this->baseMidoPath = $midoPath;
        }
        $k++;
        /*
         * create an array to hold all the classes traverse
         */
        $classes = [];
        $curFilePath = null;

        if (is_dir($midoPath)) {
            if ($curClassPath = opendir($midoPath)) {
                while (($curClass = readdir($curClassPath)) !== false) {
                    if ($curClass != "." && $curClass != "..") {
                        /*
                         * create a file path to track if this is a folder or directory
                         */
                        $curFilePath = $midoPath . '/' . $curClass;
                        if (is_dir($curFilePath)) {
                            /*
                             * recourse and loop though this directory by starting
                             * again at the top, using the focused directory
                             */
                            $this->loadAllClass($curFilePath);
                        } else {
                            /*
                             * add to our collections of classes to be loaded later
                             */
                            $classes[] = array(
                                'class' => $curClass,
                                'class_path' => $midoPath,
                                'base_path' => $this->baseMidoPath,
                            );
                        }
                    }
                }
                closedir($curClassPath);
            }
        }
        /*
         * load all the classes
         */
        //var_dump($classes);
        $this->includeClasses($classes);
        return true;
    }
}