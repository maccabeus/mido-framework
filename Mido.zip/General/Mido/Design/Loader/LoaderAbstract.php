<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Loader;

use Mido\Http\Server\Server;

abstract class LoaderAbstract
{
    /*
     * basic loader variable definition
     */
    protected $configs;
    protected $configPath;
    protected $baseMidoPath;
    protected $classList;
    protected $server;
    protected $processUri;
    protected $processFullUrl;
    protected $processQuery;
    protected $processRoot;
    protected $processMidoRoot;

    /*
     * include all the loaded classes while checking integrity
     * @param   array   $classes
     * @return  bool
     */
    public function includeClasses(array $classes)
    {
        if (!$classes) {
            return false;
        }
        foreach ($classes as $classList=> $curClass) {
            $fullClassPath= $curClass['class_path']."/" . $curClass['class'];
            $midoBasePath= $curClass['base_path'];
            if (file_exists($fullClassPath)) {
                $fileIntegrity = $this->checkClassIntegrity($fullClassPath);
                if ($fileIntegrity === true) {
                    //var_dump($curClass);
                    spl_autoload_register(function ($fullClassPath) {
                        //var_dump($fullClassPath);
                        require_once "C:\\xampp\htdocs\\".$fullClassPath;
                    });
                }
            }
        }
        return true;
    }

    /*
     * check for class integrity
     * @param   string  $class
     * @return  bool
     */
    public function checkClassIntegrity($class)
    {
        if (!$class) {
            return false;
        }
        /*
         * check file integrity here
         * @todo    update this with additional security measure in the future
         */
        return true;
    }

    /*
    * return configuration settings
    * @return  array
    */
    public function loadConfigFile()
    {
        if (!$this->processRoot) {
            $this->setServerVariables();
        }
        /*
         * load the application configuration file
         */
        $this->configPath = $this->processMidoRoot . '/config.php';
        if (file_exists($this->configPath)) {
            $config = require_once($this->configPath);
            return $config;
        } else {
            /*
             * throw exception here in the future
             */
            return 'Configuration file not found';
        }
    }

    /*
    * return server variables
    * @return  array
    */
    public function loadServerVariables()
    {
        if (!$this->processRoot) {
            $this->setServerVariables();
        }
        return $this->server;
    }

    /*
     * ---------------------------------------------------------------------------
     * Private function starts here
     * ---------------------------------------------------------------------------
     */

    /*
    * set some basic server parameters
    * @return  null
    */
    private function setServerVariables()
    {
        $serverLoader = new Server();
        $server = $serverLoader->setServerVariables();
        $this->server = $server;
        $this->processRoot = $server['process_root'];
        $this->processUri = $server['process_uri'];
        $this->processQuery = $server['process_query'];
        $this->processFullUrl = $server['process_full_url'];
        $this->processMidoRoot = $server['process_mido_root'];
    }
}