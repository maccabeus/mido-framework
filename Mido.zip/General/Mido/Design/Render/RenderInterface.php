<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Render;

interface RenderInterface
{
    /*
     * Make any current switch initiated by user
     * @param   array $switchParams
     * @return  array
     */
    public function render($switchParams);

}