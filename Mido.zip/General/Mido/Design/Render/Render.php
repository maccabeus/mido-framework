<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Render;

class Render extends RenderAbstract implements RenderInterface
{
    public function __construct()
    {
    }

    /*
     * Render any current switch initiated by user
     * @param   array $switchParams
     * @return  array
     */
    public function render($switchParams)
    {
    }

}