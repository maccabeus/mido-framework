<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Design\Render;

use Mido\Http\Session\Globals;

abstract class RenderAbstract
{
    /*
     * 
     */
    protected $config;
}