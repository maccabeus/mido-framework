<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Dictionary;

use Mido\Http\Session\Globals;

class Translator
{
    protected $language; // the language collection. usually very huge
    protected $readable; // language collection broken down to units collections
    protected $iso;     // the language iso
    protected $focus;   // this will store info about the specific area to focus in language file
    protected $focusIndex;   // this will store info about the specific area to focusIndex in language file

    /*
     * Initialize Translator
     * @param   string $focus
     * @param   string $focusIndex
     * @return  null
     */
    public function __construct($focus = null, $focusIndex = null)
    {
        /*
         * set things in motion by loading the language
         */
        $globalSpace = new Globals();
        $language = $globalSpace->get('language');
        $this->language = $language;
        /*
         * check if we are focusing on a particular section of the file
         */
        if ($focus !== null) {
            $readable = $this->loadFocus($focus, $focusIndex);
        } else {
            /*
             * attempt to auto focus on the appropriate language file
             * section using the current class and function
             */
            $readable = $this->autoLoadFocus();
        }
    }

    /*
     * Automatically loads the language file to focus using the current process
     * @return  array | null
     */
    public function autoLoadFocus($focusIndex = __FUNCTION__)
    {
        /*
         * create an autofocus index using the  class name
         */
        $focus = strtolower(__CLASS__);
        if (!isset($this->language[$focus])) {
            return null;
        }
        /*
         * check if the focusIndex is defined in language. This is usually the function name
         */
        if (!isset($this->language[$focus][$focusIndex])) {
            return null;
        } else {
            /*
             * return the specific section to read from. This is still a collection of entries
             * Each entry indicate a readable string from the language file.
             */
            $this->readable = $this->language[$focus][$focusIndex];
            $this->focus = $focus;
            $this->focusIndex = $focusIndex;
            return $this->readable;
        }
    }

    /*
     * Manually loads the language file to focus
     * @return  array | null
     */
    public function loadFocus($focus, $focusIndex)
    {
        /*
         * load the current focus manually
         */
        if (!isset($this->language[$focus])) {
            return null;
        }
        /*
         * check if the focusIndex is defined in language.
         */
        if (!isset($this->language[$focus][$focusIndex])) {
            return null;
        } else {
            $this->readable = $this->language[$focus][$focusIndex];
            $this->focus = $focus;
            $this->focusIndex = $focusIndex;
            return $this->readable;
        }
    }

    /*
     * Use to output entry in the language file for a focused section
     * @param   string $readLine
     * @return  bool
     */
    public function say($readLine)
    {
        if (!$this->readable[$readLine]) {
            return false;
        } else {
            echo($this->readable[$readLine]);
            return true;
        }
    }
}