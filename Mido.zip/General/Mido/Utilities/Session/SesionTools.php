<?php
/**
 * Mlisoft Technology / Mido Framework
 * @package Mido
 * @author  Adeniyi Anthony A   <anthony.a@mido.org>
 * @link    www.mido.org
 */

namespace Mido\Utilities\Session;

abstract class Tools
{
    /*
     * Start a new session if not existing
     * @return  bool
     */
    public function startSession()
    {
        if (!isset($_SESSION)) {
            session_start();
            return true;
        } else {
            return false;
        }
    }

    /*
     * Get a session variable
     * @return  string
     */
    public function getSessionElement($sessionKey)
    {
        $this->startSession();
        if (isset($_SESSION[$sessionKey])) {
            return $_SESSION[$sessionKey];
        } else {
            return null;
        }
    }

    /*
     * Set a session variable
     * @return  bool
     */
    public function setSessionElement($sessionKey, $newValue = null)
    {
        $this->startSession();
        $_SESSION[$sessionKey] = $newValue;
        return true;
    }
}