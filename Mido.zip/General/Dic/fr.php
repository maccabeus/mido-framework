<?php
/*
 * ---------------------------------------------------------------------------------
 * A basic language file. You must save a file just like this for every language you
 * want to support in your application within you template folder (Template/YourTemplateFolder/Resources/dic)
 * It is advised that you list items based on their method or usage reference
 * ---------------------------------------------------------------------------------
 */
return array(
    /*
     * ---------------------------------------------------------------------
     * The Mido home directory section
     * ---------------------------------------------------------------------
     */
    'default' => array(
        'resolve' => array(
            'config_failed' => 'Failed to load configuration file',
            'app_loading' => "application is loading",
            'hello' => "Hello. Application is loading",
            'invalid_mido_path' => "Mido cannot be found. Ensure it was installed properly",
            'invalid_class_path' => "Invalid class loader path. Ensure Mido was installed properly",
        ),
    ),
    /*
     * ---------------------------------------------------------------------
     *Mido library language section
     * ---------------------------------------------------------------------
     */
    'mido\dictionary\translator' => array( // this is the full class name: __CLASS__
        '__construct' => array(    // this is the class and the function name in focus
            'no_focus' => 'le no vex non ale person',
        ),
    ),

);
